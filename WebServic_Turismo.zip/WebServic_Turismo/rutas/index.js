var ruta=require('express').Router();
module.exports=(function(modelo){
    var usuario=require('../controller/ControladorUsuario.js')(modelo);
    var rol=require('../controller/ControladorRol.js')(modelo);
    ruta.get('/' ,function(peticion,respuesta){

    });
	
	
	ruta.get('/prueba', usuario.prueba);
	
    /*Ruta para Usuario*/

    ruta.post('/usuario/registro', usuario.registro);
    ruta.post('/usuario/login', usuario.login);
    

    ruta.use(usuario.tokenMiddleware);

    /*Ruta Rol*/
    ruta.get('/rol/:id',rol.list);
    ruta.post('/rol',rol.add);
    ruta.put('/rol/:id',rol.edit);
    ruta.delete('/rol/:id',rol.delete);
	
	
    ruta.get('/token',usuario.tokenGenerator);

    return ruta;
});