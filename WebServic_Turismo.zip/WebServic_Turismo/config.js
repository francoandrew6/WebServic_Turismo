module.exports={
    'secret' : "12e3413ddb60b4124e405df724cad65d",
    'database' : 'mysql://root:@localhost:3306/db_turism'

}